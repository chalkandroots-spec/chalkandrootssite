CHALK & ROOTS | CH & SAID WORD DETECTIVE COMPANION KIT
Grades 3-5

Extract this folder and open START_HERE.html.
Student_Clickable_Kit.html works without a ChatGPT account or sign-in.
Share PDFs 01-04 and the student HTML with learners. Keep PDF 05 for teachers.
Audio depends on a browser speech voice. No student work is transmitted automatically.
For classroom use; preserve Chalk & Roots attribution and website.
chalkandroots.com
